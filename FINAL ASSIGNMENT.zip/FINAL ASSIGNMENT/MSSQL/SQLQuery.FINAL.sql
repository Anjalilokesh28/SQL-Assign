﻿USE   ASSIGNMENT1

CREATE TABLE tblEmployee
(
EmployeeID int primary key,
EmployeeName varchar(50) not null,
Role varchar(50) not null,
Hiredate date default getdate(),
EmailID varchar(50) not null unique,
location varchar(50),
Salary int check(salary>15),
DepartmentID int Foreign  key references tblDepartment(DepartmentID),
)

INSERT INTO tblEmployee values(2000,'Nishanth','DB','10/16/2023','nishanth@excelindia.com','Mysore',18000,10)
INSERT INTO tblEmployee values(2001,'Sagar','Software Engineer Trainee','10/28/2023','sagar@excelindia.com','Tumkur',30000,20)
INSERT INTO tblEmployee values(2002,'Mahesh','Back end','11/20/2023','mahesh@excelindia.com','Tipturu',18000,30)
INSERT INTO tblEmployee values(2003,'Pavithra','HR','10/08/2023','pavithra@excelindia.com','Bangalore',20000,40)
INSERT INTO tblEmployee values(2004,'Anjali','HR','10/08/2023','anjali@excelindia.com','Bangalore',20000,40)
INSERT INTO tblEmployee values(2005,'Prajwal','Front end','10/16/2023','prajwal@excelindia.com','Mysore',10000,60)
INSERT INTO tblEmployee values(2006,'Bhoomika','DB','10/08/2023','bhoomika@excelindia.com','Tumkur',45000,70)
INSERT INTO tblEmployee values(2007,'Pooja','Software Trainee','08/28/2016','pooja@excelindia.com','Hebbal',15000,80)
INSERT INTO tblEmployee values(2008,'Akash','PHP developer','04/23/2012','akash@excelindia.com','Kolar',90000,90)
INSERT INTO tblEmployee values(2009,'Mouna','Sales','03/15/2023','mouna@excelindia.com','Shimoga',15000,10)

CREATE TABLE tblDepartment
(
DepartmentID int PRIMARY KEY,
EmployeeName varchar(50),
Loction varchar(50)
)

insert into tblDepartment values(10,'DB','Mysore')
insert into tblDepartment values(20,'Software Engineer Trainee','Tumkur')
insert into tblDepartment values(30,'Back end','Tipturu')
insert into tblDepartment values(40,'HR','Bangalore')
insert into tblDepartment values(50,'HR','Bangalore')
insert into tblDepartment values(60,'Front end','Mysore')
insert into tblDepartment values(70,'DB','Tumkur')
insert into tblDepartment values(80,'Software trainee','Hebbal')
insert into tblDepartment values(90,'PHP developer','Kolar')
insert into tblDepartment values(10,'Sales','Shimoga')

SELECT * FROM tblEmployee
SELECT * FROM tblDepartment

--1.Insert 10 records into each table. 

--2.Display Table information. 
SELECT * FROM tblEmployee

--3. Display Employee’s name,  EmployeeId, departmentId  from tblEmployee 
SELECT EmployeeName, EmployeeID, DepartmentID FROM tblEmployee
 
--4. Display Employee’s name,  EmployeeId, departmentId  of department 20 and 40. 
 SELECT EmployeeName, EmployeeID, DepartmentID FROM tblEmployee
 WHERE DepartmentID IN (20,40)
 
--5.Display information about all ‘ Trainees Software Engineer’  having salary less than 20000. 
 SELECT * FROM tblEmployee 
 WHERE Role='Software Engineer Trainee' AND Salary < 20000

--6. Display information about all employees of department 30 having salary greater than 
--20000. 
 SELECT * FROM tblEmployee 
 WHERE DepartmentID= 30 AND Salary >10000

--7.Display list of employees who are not allocated with Department. 

 SELECT EmployeeName FROM tblEmployee 
 WHERE DepartmentID IS NULL 

--8.Display name and department of all ‘ Business Analysts’. 

 SELECT EmployeeName, DepartmentID  
 FROM tblEmployee E
 where Role= 'HR'

--9.Display name, Designation and salary of all the employees of department 30 who earn 
--more than 20000 and less than 40000. 
SELECT EmployeeName, Role, Salary FROM tblEmployee
WHERE DepartmentID=30 AND Salary>10000 and Salary<40000

--10.Display unique job of tblEmployee. 
SELECT DISTINCT Role, EmployeeName FROM tblEmployee 

--11.Display list of employees who earn more than 20000 every year of department 20 and 30. 
SELECT * FROM tblEmployee
WHERE (Salary*12)>20000 AND DepartmentID IN (20,30)

--12.  List Designation, department no and Joined date in the format of Day, Month, and Year of 
--department 20. 
SELECT Role, DepartmentId, Format(Hiredate ,'dd/mm/yyyy') from tblEmployee where DepartmentId = 20

--13.Display employees whose name starts with an vowel
SELECT EmployeeID, EmployeeName FROM tblEmployee
WHERE EmployeeName LIKE '[aeiou]%'

--14.Display employees whose name is less than 10 characters 
SELECT EmployeeID, EmployeeName FROM tblEmployee
WHERE LEN(EmployeeName)<6

--15.Display employees who have ‘N’ in their name 
 SELECT EmployeeID, EmployeeName FROM tblEmployee
 WHERE EmployeeName LIKE '%N%'

--16.Display the employees with more than three years of experience 
 SELECT EmployeeID, EmployeeName FROM tblEmployee
 WHERE DATEDIFF(YEAR,Hiredate,GETDATE())>3

--17.Display employees who joined on Monday 
SELECT * FROM tblEmployee 
WHERE DATENAME(DW,Hiredate)='Monday'

--18.Display employees who joined on 1st. 
SELECT * FROM tblEmployee
WHERE DATEPART(D,Hiredate)= 1

--19.Display all Employees joined in January 
SELECT * FROM tblEmployee
WHERE DATENAME(MONTH,Hiredate)='JANUARY'

--20.Display Employees with their Initials. 
SELECT CONCAT(EmployeeName,' ',Role) FROM tblEmployee


------------------------------------------ASSIGNMENT 2

--TABLE CREATION (CONSTRAINTS)

-------------------------------------------------------------------------------------------------------------
------------------------------------------ASSSIGNMENT 3

Create TABLE tblEmployee3
(
EmployeeId int,
EmployeeName varchar(50),
Designation varchar(50),
JoinedDate Datetime,
EmailId varchar(50),
Salary money,
Location varchar(25),
DepartmentId int
)

INSERT INTO tblEmployee3 values
(1001,'Bhoomika R','Trainee Software engineer','10/16/2023','bhoomi@gmail.com','25000','mysore','1')
INSERT INTO tblEmployee3 values
(1002,'Pooja','HR','10/16/2023','pooja@gmail.com','50000','mysore','2')
INSERT INTO tblEmployee3 values
(1003,'Anjali','Trainee Software engineer','11/16/2023','anj@gmail.com','60000','mysore','1')
INSERT INTO tblEmployee3 values
(1004,'Pavithra','IT','10/16/2023','pavithra@gmail.com','25000','Noida','3')
INSERT INTO tblEmployee3 values
(1005,'Lavanya','Marketing','10/16/2019','lavanya@gmail.com','70000','banglore','4')
INSERT INTO tblEmployee3 values
(1006,'Mouna','IT','01/18/2023','mouna@gmail.com','80000','mysore','3')
INSERT INTO tblEmployee3 values
(1007,'Bhanu','Buisness Analyst','10/16/2023','bhanu@gmail.com','90000','noida','5')
INSERT INTO tblEmployee3 values
(1008,'Akash','HR','10/16/2023','akash@gmail.com','60000','banglore','2')
INSERT INTO tblEmployee3 values
(1009,'Vivek','Marketing','10/8/2023','Vivek@gmail.com','50000','mysore','4')
INSERT INTO tblEmployee3 values
(1010,'Nischay','IT','10/16/2023','Nischay@gmail.com','25000','banglore','3')

--1.Display all the employees data by sorting the date of joining in the ascending order and 
--then by name in descending order. 
SELECT * FROM tblEmployee3
ORDER BY EmployeeName DESC, JoinedDate ASC 

--2.Write a query to change the table name to Employees. 
EXEC sp_rename 'tblEmp3','tblEmployee3'

--3.Write a query to update the salary of those employees whose location is ‘Mysore’ to 35000. 
UPDATE tblEmployee3  
SET Salary= 35000
WHERE Location='mysore'

--4.Write a query to disassociate all trainees from their department  
update tblEmployee3
set Designation=' '
where Designation ='Trainee Software engineer'

--5.Write a query which adds another column ‘Bonus’ to the table Employees where the bonus 
--is equal to the salary multiplied by ten. Update the value only when the experience is two 
--years or above. 
alter table tblEmployee3
add Bonus money

--6.Display name and salary of top 5 salaried employees from Mysore and Hyderabad. 
SELECT  TOP 5 Salary, EmployeeName FROM tblEmployee3
WHERE Location IN ('mysore','hyderabad')
ORDER BY Salary

--7.Display name and salary of top 3 salaried employees(Include employees with tie) 
SELECT TOP 3 WITH TIES Salary, EmployeeName FROM tblEmployee3
ORDER BY Salary DESC

--8.Display top 1% salaried employees from Noida and Bangalore 
SELECT TOP 1 Salary, EmployeeName FROM tblEmployee3
WHERE Location IN ('Noida','Banglore')
ORDER BY Salary 

--9.Find average and total salary for each job. 
SELECT AVG(Salary) AS AvgSalary , SUM(Salary) AS TotalSalary, Designation
FROM tblEmployee3
GROUP BY Designation

--10.Find highest salary of all departments. 
SELECT MAX(Salary) MaxSalary, Designation FROM tblEmployee3
GROUP BY Designation

--11.Find minimum salary of all departments. 
SELECT MIN(Salary) MaxSalary, Designation FROM tblEmployee3
GROUP BY Designation

--12.Find difference in highest and lowest salary for all departments. 
SELECT (MAX(Salary)-MIN(Salary))  
FROM tblEmployee3
GROUP BY Designation

--13.Find average and total salary for trainees 
select avg(salary) as Maxsalary,sum(salary) as Sumsalary
from tblEmployee3
where Designation='Trainee Software engineer'

--14.Count total different jobs held by dept no 30 
select COUNT(distinct Designation) as Designations
from tblEmployee3
where departmentID=3

--15.Find highest and lowest salary for non-managerial job 
select max(salary) as higestsalary, min(salary) as lowestsalary
from tblEmployee3
where Designation not like'%manager%'

--16.Count employees and  average annual salary of each department.
select count(EmployeeName) as Employee, avg(salary*12) AS AvgAnnualSalary ,Designation
from tblEmployee3
group by designation;

--17.Display the number of employees sharing same joining date.
select JoinedDate, count(*) from tblEmployee3
group by JoinedDate
having count(*)>1

--18.Display total number of employees in each department with same salary 
select Designation ,salary, count(*) AS NoOfEmployees FROM tblEmployee3
group by designation,salary
having count(*)>1

--19.Display the  number of Employees above 35 years in each department 
select designation ,count(*) as above35years   
from tblEmployee3
where datediff( yyyy,JoinedDate,getdate())>3
group by designation;

------------------------------ASSIGNMENT4--------------------------------------

SELECT * FROM tblEmployee
SELECT * FROM tblDepartment

CREATE Table Salesman(
 Salesman_num int primary key, Salesman_name varchar(20), city varchar(10), commission int)


 INSERT INTO Salesman(Salesman_num,Salesman_name,city,commission)
 values(1001,'piyush','london',0.11)
 INSERT INTO Salesman(Salesman_num,Salesman_name,city,commission)
 values(1002,'sejal','surat', 0.10)
INSERT INTO Salesman(Salesman_num,Salesman_name,city,commission)
 values (1004,'rashmi','london', 0.21)
	 INSERT INTO Salesman(Salesman_num,Salesman_name,city,commission)
	    values (1007,'rajesh','baroda', 0.14)
	 INSERT INTO Salesman(Salesman_num,Salesman_name,city,commission)
	    values (1003,'anand','new delhi', 0.15)

		SELECT * FROM Salesman


 CREATE Table Customer(
 Customer_num int primary key, Customer_name varchar(20), city varchar(10),Rating Int,Salesman_num int references Salesman(Salesman_num)) 

 INSERT INTO Customer(Customer_num,customer_name,city,Rating,Salesman_num)
 VALUES(2001,'Harsh','london',100,1001)
 INSERT INTO Customer(Customer_num,customer_name,city,Rating,Salesman_num)
 VALUES(2002,'gita','rome',200,1003)
 INSERT INTO Customer(Customer_num,customer_name,city,Rating,Salesman_num)
 VALUES(2003,'lalit','surat',200,1002)
 INSERT INTO Customer(Customer_num,customer_name,city,Rating,Salesman_num)
 VALUES(2004,'govind','bombay',300,1002)
 INSERT INTO Customer(Customer_num,customer_name,city,Rating,Salesman_num)
 VALUES(2006,'chirag','london',100,1001)
 INSERT INTO Customer(Customer_num,customer_name,city,Rating,Salesman_num)
 VALUES(2008,'chinmay','surat',300,1007)
 INSERT INTO Customer(Customer_num,customer_name,city,Rating,Salesman_num)
 VALUES(2007,'pratik','rome',100,1004)

 SELECT * FROM Customer

 
  CREATE Table ORDERS(
 ord_num int primary key,ord_amt decimal (7,2),Ord_Date Datetime, customer_num int references customer(customer_num) ,salesman_num int references salesman(salesman_num))

 INSERT INTO ORDERS(ord_num,ord_amt,ord_Date,customer_num,Salesman_num)
 VALUES(3001,18.69,'10-03-06',2008,1007)
 INSERT INTO ORDERS(ord_num,ord_amt,ord_Date,customer_num,Salesman_num)
 VALUES(3003,767.19,'10-03-06',2001,1001)
 INSERT INTO ORDERS(ord_num,ord_amt,ord_Date,customer_num,Salesman_num)
 VALUES(3002,1900.10,'10-03-06',2007,1004)
 INSERT INTO ORDERS(ord_num,ord_amt,ord_Date,customer_num,Salesman_num)
 VALUES(3005,5160.45,'10-03-06',2003,1002)
 INSERT INTO ORDERS(ord_num,ord_amt,ord_Date,customer_num,Salesman_num)
 VALUES(3006,1098.16,'10-03-06',2008,1007)
 INSERT INTO ORDERS(ord_num,ord_amt,ord_Date,customer_num,Salesman_num)
 VALUES(3009,1713.23,'10-04-06',2002,1003)
 INSERT INTO ORDERS(ord_num,ord_amt,ord_Date,customer_num,Salesman_num)
 VALUES(3007,75.75,'10-04-06',2004,1002)
 INSERT INTO ORDERS(ord_num,ord_amt,ord_Date,customer_num,Salesman_num)
 VALUES(3008,4723.00,'10-05-06',2006,1001)
 INSERT INTO ORDERS(ord_num,ord_amt,ord_Date,customer_num,Salesman_num)
 VALUES(3010,1309.95,'10-06-06',2004,1002)
 INSERT INTO ORDERS(ord_num,ord_amt,ord_Date,customer_num,Salesman_num)
 VALUES(3011,9891.88,'10-06-06',2006,1001)

  SELECT * FROM ORDERS
	
1.  SELECT ord_num ,customer_name, ord_amt ,ord_Date
    FROM Customer INNER JOIN Orders
    on ORDERS.customer_num = Customer.Customer_num
 
2.  SELECT Customer_name,Salesman_name
    FROM Customer
    RIGHT JOIN Salesman on Salesman.Salesman_num=Customer.Salesman_num

3.  SELECT ord_num,Customer_name,Salesman_name,ord_amt,ord_Date 
    FROM Customer INNER JOIN ORDERS
    on Customer.Customer_num=ORDERS.customer_num INNER JOIN Salesman on Salesman.Salesman_num= ORDERS.salesman_num

4.  SELECT Salesman_name,customer_name,ord_amt,ord_num,Ord_Date
    from ORDERS 
    join customer on ORDERS.Customer_num=Customer.Customer_nUM
    Right join salesman on ORDERS.Salesman_num=Salesman.Salesman_num
    order by ord_amt desc
	
5.  SELECT Customer_name,ord_amt,ord_date
    FROM Customer left join ORDERS
    ON Customer.Customer_num=ORDERS.customer_num
    order by ord_Date asc

6.  SELECT Salesman_name, count(Customer_num)
    FROM Customer
    RIGHT JOIN Salesman on Salesman.Salesman_num=Customer.Salesman_num
    group by Salesman_name
  
7.  SELECT Customer_name, COUNT(ord_num) as 'orders number'
    from customer 
	left join ORDERS ON ORDERS.customer_num=Customer.Customer_num
    GROUP BY Customer_name
    having count(ord_num)>1

8.  SELECT  Customer.city as 'Customer city',count(ord_num) as totalorder,sum(ord_amt)as totalrevenue
    FROM Customer left JOIN ORDERS
	on Customer.Customer_num=ORDERS.customer_num 
	group by Customer.city

-----------------------------ASSIGNMENT 5 TOYS---------------------------------------
create table customer1(
custId int Primary key,
custname varchar(50) not null,
custtype char(1)
)

create table category1(
Cid char(4)Primary key,
Cname varchar(50))

create table toys1(
ToyId char(5) primary key,
Toyname varchar(50) Unique not null,
Cid char(4) foreign key references category1(Cid) not null,
price Money not null ,
stock int not null
)

create table transactions(
TxnId int primary key,
custId int foreign key references customer1(custid),
ToyId char(5) foreign key references toys1(ToyId),
Quantity int, 
TxnCost int) 

-- Insert data into customer table
INSERT INTO customer1 (custId, custname, custtype)
VALUES
    (1, 'John Doe', 'R'),
    (2, 'Jane Smith', 'W'),
    (3, 'Bob Johnson', 'R'),
    (4, 'Alice Williams', 'W');

-- Insert data into category table
INSERT INTO category1 (Cid, Cname)
VALUES
    ('CAT1', 'Action Figures'),
    ('CAT2', 'Dolls'),
    ('CAT3', 'Board Games'),
    ('CAT4', 'Educational Toys');

-- Insert data into toys table
INSERT INTO toys1 (ToyId, Toyname, Cid, price, stock)
VALUES
    ('T1001', 'Super Hero Action Figure', 'CAT1', 19.99, 50),
    ('T1002', 'Fashion Doll', 'CAT2', 15.99, 30),
    ('T1003', 'Chess Set', 'CAT3', 29.99, 20),
    ('T1004', 'Alphabet Blocks', 'CAT4', 12.99, 40);

-- Insert data into transactions table
INSERT INTO transactions (TxnId, custId, ToyId, Quantity, TxnCost)
VALUES
    (101, 1, 'T1001', 2, 39.98),
    (102, 2, 'T1002', 1, 15.99),
    (103, 3, 'T1003', 1, 29.99),
    (104, 4, 'T1004', 3, 38.97);


---1.Display CustName and total transaction cost as TotalPurchase for those customers whose total transaction cost is greater than 1000. 

select   c.custname , sum(T.TxnCost)as TotalPurchase from 
customer1 c 
inner join transactions t on c.custId=t.custId
group by c.custname
having sum(t.TxnCost) >1000

---2.List all the toyid, total quantity purchased as 'total quantity' irrespective of the 
--customer. Toys that have not been sold should also appear in the result with total units as 0 

select t.toyId, COALESCE(count(t1.quantity), 0)from 
toys1 t 
inner join transactions t1 on 
t.toyId=t1.ToyId
group by t.toyId

----3.The CEO of Toys corner wants to know which toy has the highest total Quantity sold. 
---Display CName, ToyName, total Quantity sold of this toy. 

SELECT TOP 1
    c.Cname AS CategoryName,
    t.Toyname AS ToyName,
    SUM(tr.Quantity) AS TotalQuantitySold
FROM 
    category1 c
JOIN 
    toys1 t ON c.Cid = t.Cid
JOIN 
    transactions tr ON t.ToyId = tr.ToyId
GROUP BY 
    c.Cname, t.Toyname
ORDER BY 
    TotalQuantitySold DESC;


------------------------------ASSIGNMENT 5 HEALTH CARE------------------------------------------
create  table patient (
pId int primary key ,
pName varchar(50),
city varchar(50))


create  table doctor (
dId varchar(11) primary key ,
dName varchar (50),
dept varchar(50),
salary int )

create table consultation(
cId int primary key ,
pId int references patient(pId),
dId varchar(11) references doctor(dId),
fees int)

-- Insert data into the patient table
INSERT INTO patient (pId, pName, city) VALUES
(1, 'John Doe', 'New York'),
(2, 'Alice Smith', 'Los Angeles'),
(3, 'Bob Johnson', 'Chicago'),
(4, 'Emily Davis', 'San Francisco'),
(5, 'Michael Wilson', 'Houston');

-- Insert data into the doctor table
INSERT INTO doctor (dId, dName, dept, salary) VALUES
('D001', 'Dr. Anderson', 'Cardiology', 120000),
('D002', 'Dr. Garcia', 'Orthopedics', 110000),
('D003', 'Dr. Lee', 'Neurology', 130000),
('D004', 'Dr. Robinson', 'Pediatrics', 100000),
('D005', 'Dr. Patel', 'Dermatology', 115000);

-- Insert data into the consultation table
INSERT INTO consultation (cId, pId, dId, fees) VALUES
(101, 1, 'D001', 150),
(102, 2, 'D002', 120),
(103, 3, 'D003', 180),
(104, 4, 'D004', 100),
(105, 5, 'D005', 130);

--Identify the consultation details of patients with the letter ‘e’ anywhere in their name, who 
--have consulted a cardiologist. Write a SQL query to display doctor’s name and patient’s 
--name for the identified consultation details. 

Select p.pId,p.pName,p.city,c.cId,c.fees,d.dName from consultation c
inner join patient p on 
c.pId=p.pId left join doctor d on c.dId=d.dId
where pName like'%e%'

---Identify the doctors who have provided consultation to patients from the cities ‘Boston’ 
---and ‘Chicago’. Write a SQL query to display department and number of patients as 
---PATIENTS who consulted the identified doctor(s). 

SELECT d.did,d.dname AS Doctor_Name,p.city
FROM patient p
inner JOIN consultation
ON consultation.pid = p.pid
inner JOIN doctor d 
on consultation.did = d.did
WHERE p.city IN ('Boston','Chicago');
  

---Identify the cardiologist(s) who have provided consultation to more than one patient. 
---Write a SQL query to display doctor’s id and doctor’s name for the identified 
---cardiologists. 

SELECT d.dId,d.dname AS Doctor_Name
FROM patient
JOIN consultation
ON consultation.pId = patient.pId
JOIN doctor d
on consultation.did = d.did
WHERE d.dept = 'Cardiology'
GROUP BY d.did,d.dname
HAVING COUNT(d.did) >1;

--Question 4: Write a SQL query to combine the results of the following two reports into a single report.
--The query result should NOT contain duplicate records.
--Report 1 – Display doctor’s id of all cardiologists who have been consulted by
--patients.
--Report 2 – Display doctor’s id of all doctors whose total consultation fee charged
--in the portal is more than INR 800.

SELECT d.did
FROM patient p
JOIN consultation
ON consultation.pid = p.pid
JOIN doctor d
on consultation.dId = d.did
GROUP BY d.did,d.dname
HAVING COUNT(d.did) >=1
UNION
SELECT d.did
FROM patient p
JOIN consultation
ON consultation.pid = p.pid
JOIN doctor d
on consultation.did = d.did
WHERE consultation.fees  > 800

/*
Question 5: Write a SQL query to combine the results of the following two reports into a single report.
The query result should NOT contain duplicate records.
Report 1 – Display patient’s id belonging to ‘New York’ city who have consulted
with the doctor(s) through the portal.
Report 2 – Display patient’s id who have consulted with doctors other than
cardiologists and have paid a total consultation fee less than INR 1000.
*/

SELECT p.pid
FROM patient p INNER
JOIN consultation
ON consultation.pid = p.pid
inner JOIN doctor d
on consultation.did = d.did
WHERE p.city = 'New York'
UNION
SELECT p.pid
FROM patient p
inner JOIN consultation
ON consultation.pid = p.pid
inner JOIN doctor
on consultation.did = doctor.did
WHERE consultation.fees  < 1000 AND doctor.dept != 'cardiology';


-------------------------------ASSGINMENT6 banking----------------------------------------
create table accountType(
AccType int primary key ,
AccName varchar(30))

create table transactionType(
TransType int primary key,
TransName varchar (50))

create table CustomerDetails (
 AccNo int primary key,
 CustName varchar(50),
 address varchar(50),
 AccType int references AccountType(Acctype))

create table AccountTransaction (
Tid int primary key ,
AccNo int references CustomerDetails(AccNo),
Amount money,
dateoftrans date,
TransType int references TransactionType(transtype))

-- Insert data into the AccountType table
INSERT INTO AccountType (AccType, AccName)
VALUES
    (1, 'Savings Account'),
    (2, 'Checking Account'),
    (3, 'Fixed Deposit'),
    (4, 'Credit Card'),
    (5, 'Loan Account');

-- Insert data into the TransactionType table
INSERT INTO TransactionType (TransType, TransName)
VALUES
    (1, 'Deposit'),
    (2, 'Withdrawal'),
    (3, 'Transfer'),
    (4, 'Payment'),
    (5, 'Purchase');

-- Insert data into the CustomerDetails table
INSERT INTO CustomerDetails (AccNo, CustName,address, AccType)
VALUES
    (1001, 'John Smith','Mysore', 1),
    (1002, 'Mary Johnson','bengaluru', 2),
    (1003, 'David Lee','mandya', 3),
    (1004, 'Sara Clark','madikeri', 1),
    (1005, 'Robert White','mangaluru', 2);
	

-- Insert data into the AccountTransaction table
INSERT INTO AccountTransaction (Tid, AccNo, Amount, dateoftrans, TransType)
VALUES
    (2001, 1001, 1000.00, '2023-10-15', 1),
    (2002, 1002, 500.00, '2023-10-16', 2),
    (2003, 1003, 15000.00, '2023-10-17', 1),
    (2004, 1001, 250.00, '2023-10-18', 4),
    (2005, 1005, 3000.00, '2023-10-19', 3);



--1.List the Customer with transaction details who has done third lowest  
--transaction 

SELECT Top 1 CustomerDetails.CustName,AccountTransaction.Amount
FROM CustomerDetails
INNER JOIN AccountTransaction
ON AccountTransaction.AccNo = CustomerDetails.AccNo
WHERE AccountTransaction.Amount NOT IN (SELECT TOP 2 AccountTransaction.Amount
FROM AccountTransaction
ORDER BY AccountTransaction.Amount DESC)
ORDER BY AccountTransaction.Amount DESC;


select * from AccountTransaction
--2.List the customers who has done more transactions than average number of  transaction  
  SELECT AccountTransaction.AccNo,COUNT(AccountTransaction.AccNo)
FROM AccountTransaction
GROUP BY AccountTransaction.AccNo
HAVING COUNT(AccountTransaction.AccNo) >(SELECT AVG(accountTransaction.accno)
FROM (SELECT COUNT(AccountTransaction.Tid)
FROM AccountTransaction
GROUP BY AccountTransaction.AccNo )


/*3.List the total transactions under each account type. */

SELECT AccountTransaction.AccNo,COUNT(AccountTransaction.Tid) AS NUM_OF_TRANS
FROM AccountTransaction
GROUP BY AccountTransaction.AccNo;

/*4.List the total amount of transaction under each account type */

SELECT AccountTransaction.AccNo,SUM(AccountTransaction.Amount) AS NUM_OF_TRANS
FROM AccountTransaction
GROUP BY AccountTransaction.AccNo;

/*5. List the total tranctions along with the total amount on a Sunday. */

SELECT Tid,COUNT(Tid),SUM(AccountTransaction.Amount) AS NUM_OF_TRANS
FROM AccountTransaction
WHERE DATENAME(DW,DateOfTrans) = 'sunday'
GROUP BY Tid;


--7. List the total amount of transactions of Mysore customers.

SELECT SUM(AccountTransaction.Amount) AS Total_Amt
FROM AccountTransaction
INNER JOIN CustomerDetails
ON CustomerDetails.AccNo = AccountTransaction.AccNo
WHERE address = 'Mysore'


select * from AccountTransaction 
select * from CustomerDetails 

/*
8. List the name,account type and the number of transactions performed by each customer
*/

SELECT CustomerDetails.CustName,AccountType.AccName,COUNT(AccountTransaction.Tid) AS NUM_OF_Transaction
FROM CustomerDetails
left outer JOIN AccountTransaction
ON CustomerDetails.AccNo = AccountTransaction.AccNo
inner JOIN AccountType
ON CustomerDetails.AccType = AccountType.AccType
GROUP BY CustomerDetails.CustName,AccountType.AccName;


/*9. List the amount of transaction from each Location. */

SELECT CustomerDetails.address,COUNT(AccountTransaction.Tid)
FROM AccountTransaction
INNER JOIN CustomerDetails
ON CustomerDetails.AccNo = AccountTransaction.AccNo
GROUP BY CustomerDetails.address;

/*10. Find out the number of customers  Under Each Account Type */

SELECT a.AccName,COUNT(c.Accno) AS Number_Of_Customer
FROM AccountType a 
left outer join CustomerDetails c
on a.AccType=c.AccType
GROUP BY a.AccName;

select * from accountType
select * from transactionType
select * from CustomerDetails
select * from AccountTransaction 

-------------------------------------ASSIGNMENT 7 salesman-----------------------------------------

-- Create the Salesman table
CREATE TABLE Salesman1 (
    Sid INT PRIMARY KEY,
    Sname VARCHAR(50),
    Location VARCHAR(50)
);

-- Create the Product table
CREATE TABLE Product (
    Prodid INT PRIMARY KEY,
    Pdesc VARCHAR(100),
    Price DECIMAL(10, 2),
    Category VARCHAR(50),
    Discount DECIMAL(5, 2)
);

-- Create the Sale table
CREATE TABLE Sale (
    Saleid INT PRIMARY KEY,
    Sid INT,
    Sldate DATE,
    Amount DECIMAL(10, 2),
    FOREIGN KEY (Sid) REFERENCES Salesman1(Sid)
);

-- Create the Saledetail table
CREATE TABLE Saledetail (
    Saleid INT,
    Prodid INT,
    Quantity INT,
    FOREIGN KEY (Saleid) REFERENCES Sale(Saleid),
    FOREIGN KEY (Prodid) REFERENCES Product(Prodid)
);


INSERT INTO Salesman1(Sid, Sname, Location)
VALUES
    (1, 'John Smith', 'New York'),
    (2, 'Jane Doe', 'Los Angeles'),
    (3, 'Robert Johnson', 'Chicago'),
    (4, 'Alice Brown', 'Houston'),
    (5, 'Michael Davis', 'Miami');


INSERT INTO Product (Prodid, Pdesc, Price, Category, Discount)
VALUES
    (101, 'Laptop', 800.00, 'Electronics', 0.10),
    (102, 'Smartphone', 500.00, 'Electronics', 0.05),
    (103, 'Desk Chair', 100.00, 'Furniture', 0.15),
    (104, 'Coffee Maker', 50.00, 'Appliances', 0.08),
    (105, 'T-shirt', 20.00, 'Clothing', 0.20);


INSERT INTO Sale (Saleid, Sid, Sldate, Amount)
VALUES
    (1001, 1, '2023-10-30', 720.00),
    (1002, 2, '2023-10-30', 475.00),
    (1003, 3, '2023-10-30', 95.00),
    (1004, 4, '2023-10-30', 42.00),
    (1005, 5, '2023-10-30', 15.00);

INSERT INTO Saledetail (Saleid, Prodid, Quantity)
VALUES
    (1001, 101, 2),
    (1002, 102, 1),
    (1003, 103, 4),
    (1004, 104, 3),
    (1005, 105, 5);

	select*
	from Salesman1

	select*
	from product
	select*
	from sale

	select*
	from saledetail


---1  Display the sale id and date for most recent sale. 

	select sid, sldate from Sale
	where sldate=(select max(Sldate) from Sale )


---2  Display the names of salesmen who have made at least 2 sales. 
SELECT Sname
FROM Salesman1
WHERE sid IN (
    SELECT Sid
    FROM Sale
    GROUP BY Sid
    HAVING COUNT(*) >= 2)

3. select top 1 with ties prodid
from saledetail
group by prodid
order by sum(quantity);


---- 4.Display SId, SName and Location of those salesmen who have total sales 
---amount greater than average sales amount of all the sales made. Amount can 
----be calculated from Price and Discount of Product and Quantity sold. 
select m.Sid,m.Sname,m.Location
From Salesman1 s
where Sid in (Select Sid
              from Sale
			  group by location
			  having sum((Price-discount)*quantity)>(select Avg (totalSales)
			                                            from (select sum(p.price),s.location
														from sale s inner join Salesman1 M
														ON s.sid=m.sid
														group by m.location)
	
	select * from sale
	select * from saledetail
	select * from Salesman1
	select * from product

--Corelated Subquery 
--5.Display the product id, category, description and price for those products whose 
--price is maximum in each category. 

SELECT p.Prodid, p.Category, p.Pdesc, p.Price
FROM Product p
WHERE p.Price = (
    SELECT MAX(p2.Price)
    FROM Product p2
    WHERE p2.Category = p.Category
);

---6.Display the names of salesmen who have not made any sales. 
SELECT Sname
FROM Salesman1
WHERE Sid NOT IN (
    SELECT DISTINCT Sid
    FROM Sale
);

--7.Display the names of salesmen who have made at least 1 sale in the month of 
---Jun 2015. 

SELECT DISTINCT Sname
FROM Salesman1 s
JOIN Sale sa ON s.Sid = sa.Sid
WHERE sa.Sldate >= '2015-06-01' AND sa.Sldate <='2015-06-30'

-------------------------------------ASSIGNMENT 8 tsql--------------------------------------------
 Create table tblstudentdetails(
StudentID int Primary Key,
StudentName varchar(50) not null,
DateOfBirth date,
Gender char(1));

Create Table Grade(
StudentID int references tblStudentdetails(StudentId),
MarksObtained int ,
Grade char(1));


3. select s.StudentName,s.StudentiD,g.Marksobtained,
case
When MarksObtained >=90 then 'A'
when MarksObtained>=80 then 'B'
when MarksObtained>=70 then 'c'
when marksObtained >=60 then 'D'
when marksObtained >=50 then 'f'
else 'failed'
end as Grade
from Grade G,tblstudentdetails S

4. select EmployeeName, JoinDate,
case
when DatePart(Month,Joindate)=1 then 'january'
when DatePart(Month,Joindate)=2 then 'february'
when DatePart(Month,Joindate)=3 then 'march'
when DatePart(Month,Joindate)=4 then 'april'
when DatePart(Month,Joindate)=5 then 'may'
when DatePart(Month,Joindate)=6 then 'june'
when DatePart(Month,Joindate)=7 then 'july'
when DatePart(Month,Joindate)=8 then 'august'
when DatePart(Month,Joindate)=9 then 'september'
when DatePart(Month,Joindate)=10 then 'october'
when DatePart(Month,Joindate)=11 then 'november'
when DatePart(Month,Joindate)=12 then 'december'
END AS joindate
from tblemployee

5. DECLARE @NUM INT =0
DECLARE @NUM INT =1001
WHILE

6. Update tblemployee
SET Bonus =
CASE
WHEN DATEDIFF(YY,GETDATE(),JOINDATE)>10 then salary
WHEN DATEDIFF(YY,GETDATE(),JOINDATE) BETWEEN 5 AND 10 THEN 0.5*SALARY
ELSE 5000
END

SELECT SALARY, BONUS
FROM TBLEMPLOYEE
-------------------------------------ASSIGNMENT 9 STORED PROCEDURES--------------------------------------------

1. What are types of Variables and mention the difference between them 
LOCAL VARIABLES AND GLOBAL VARIABLES
LV are declared and used within the scope of a specific script or stored procedure
GV are used to store data that can be accessed across different SQL statements within a session

2. Declare a variable with name [SQLData] which can store a string datatype  
and assign a value to using SELECT option and specify an alias name for the same 
DECLARE @SQLData VARCHAR(20)
SELECT @SQLData='Mysore' as 'SQLData'

3. What is used to define a SQL variable to put a value in a variable? 
a. SET @id = 6; 
b. SET id = 6; 
c. Id = 6; 
d. SET #id = 6; 
 
Select the correct option a. SET @id = 6;
 
4. Compare Local and Global Temporary tables with an Example 
CREATE TABLE #LocalTempTable
 
5. Create a table with an IDENTITY column whose Seed value is 2 and Increment value of 100 
    CREATE TABLE tblStudent 
( 
StudID INT IDENTITY(2,100),
StudName varchar(20),
)
 
6. What is the difference between SCOPE_IDENTITY() and @@IDENTITY. Explain with an 
Example.
SCOPE_IDENTITY() is a function that returns the last identity value generated within the session
is a system variable that returns the last identity value genrated for any table in the current session, irrespective of the scope or table where the insert operation occured.
INSERT INTO tblStudent VALUES ('12','BHOOMIKA');
SCOPE_IDENTITY() AS 'LastIdentity';

CREATE TABLE tblProject 
( 
   ProjectId BIGINT PRIMARY KEY, 
   PName VARCHAR(100) NOT NULL, 
   PCode NVARCHAR(50) NOT NULL, 
   ExamYear SMALLINT NOT NULL 
); 
 
 
CREATE TABLE tblExamCentre  
( 
  ExamCentreId BIGINT PRIMARY KEY, 
  ECode VARCHAR(100) NULL, 
  EName VARCHAR(100)  NULL 
); 
 
CREATE  TABLE tblProjectExamCentre 
( 
   ProjectExamCentreId BIGINT PRIMARY KEY, 
   ExamCentreId BIGINT NOT NULL FOREIGN KEY REFERENCES tblExamCentre(ExamCentreId), 
   ProjectId BIGINT FOREIGN KEY REFERENCES tblProject(ProjectId) 
); 
 
INSERT INTO tblProject(ProjectId,PName,PCode,ExamYear) VALUES 
(1,'8808-01-CW-YE-GCEA-2022','PJ0001',2022), 
(2,'6128-02-CW-YE-GCENT-2022','PJ0002',2022), 
(3, '7055-02-CW-YE-GCENA-2022','PJ0003',2022), 
(4,'8882-01-CW-YE-GCEA-2022','PJ0004',2022), 
(5,'7062-02-CW-YE-GCENT-2022','PJ0005',2022), 
(8,'6128-02-CW-YE-GCENT-1000','PJ0008',1000), 
(9,'7062-02-CW-YE-GCENT-5000','PJ0009',5000), 
(10,'8808-01-CW-YE-GCEA-2023','PJ0010',2023), 
(11,'8808-01-CW-YE-GCEA-2196','PJ0011',2196), 
(15,'6073-02-CW-YE-GCENA-2022','PJ0015',2022), 
(16,'8808-01-CW-YE-GCE0-2022','PJ0016',2022); 
 
 
INSERT INTO tblExamCentre(ExamCentreId,EName,ECode) VALUES 
(112,'VICTORIA SCHOOL-GCENA-S','2711'), 
(185,'NORTHBROOKS SECONDARY SCHOOL-GCENA-S','2746'), 
(227,'YIO CHU KANG SECONDARY SCHOOL-GCENA-S','2721'), 
(302,'CATHOLIC JUNIOR COLLEGE','9066'), 
(303,'ANGLO-CHINESE JUNIOR COLLEGE','9067'), 
(304,'ST. ANDREW''S JUNIOR COLLEGE','9068'), 
(305,'NANYANG JUNIOR COLLEGE','9069'), 
(306,'HWA CHONG INSTITUTION','9070'), 
(1,NULL,'2011'), 
(2,'NORTHBROOKS SECONDARY SCHOOL-GCENA-S',NULL); 
 
 
INSERT INTO tblProjectExamCentre(ProjectExamCentreId,ProjectId,ExamCentreId) VALUES 
(44,1,112), 
(45,1,227), 
(46,1,185), 
(47,2,112), 
(48,2,227), 
(49,2,185), 
(50,3,112), 
(51,3,227), 
(52,3,185), 
(69,4,112); 
 
select * from tblProject 
select * from tblExamCentre 
select * from tblProjectExamCentre 

----1.Write a procedure to fetch the ProjectId, ProjectName, ProjectCode, ExamCentreName 
--and ExamCentreCode from the tables tblProject and  
--tblExamCentre based on the ProjectId and ExamCentreId passed as input parameters. 

 CREATE  PROCEDURE usp_Question8
 @projectId int,
 @ExamcentreId int,
 @EXAMYEAR DATE
 AS
 BEGIN

    SELECT PROJECTID,PNAME,PCODE,EXAMYEAR
    FROM TBLPROJECT 
    WHERE PROJECTID=@PROJECTID
    SELECT ENAME,ECODE
    FROM TBLEXAMCENTRE
    WHERE ExamCentreId=@ExamCentreId
END

USP_QUESTION8 1,112,'2022-10-10'

 --2. 2.Write a procedure to insert values into the table tblProject when the data for the 
--ProjectId  
--which is being inserted does not exist in the table. 

CREATE PROCEDURE USP_QUESTION9
@PROJECTID INT,
@PNAME VARCHAR(50),
@PCODE VARCHAR(10),
@EXAMYEAR INT
AS
BEGIN
   IF NOT EXISTS(SELECT PROJECTID,PNAME,PCODE
                      FROM TBLPROJECT
					  WHERE PROJECTID=@PROJECTID)

					 INSERT INTO TBLPROJECT(PROJECTID,PNAME,PCODE,EXAMYEAR)
					 VALUES (@PROJECTID,'8808-01-CW-YE-GCE9-2020','PJ0017',2020)
					 END

EXECUTE USP_QUESTION9 @PROJECTID=17,@PNAME='8808-01-CW-YE-GCE9-2020',@PCODE='PJ0017',@EXAMYEAR=2020
    
 
-- 3.Write a procedure to update the columns-Code and Name in tblExamCentre when 
--either of the Code or the Name column is NULL  
--and also delete the records from the table tblProjectExamCentre when ProjectId IS 4. 

CREATE PROCEDURE USP_QUESTION10

AS
BEGIN
UPDATE tblExamCentre
SET Ecode=4211
WHERE ECODE IS NULL

UPDATE tblExamCentre
SET Ename='abbs'
WHERE ENAME IS NULL

   delete  from tblPROJECT where PROJECTID=4

   end 
  EXECUTE USP_QUESTION10 

  SELECT*
  FROM TBLPROJECT

  ---4.Write a procedure to fetch the total count of records present in the table tblProject 
--based on the ProjectId AS OUTPUT parameter 
--and also sort the records in ascending order based on the ProjectName. 

CREATE OR ALTER PROCEDURE USP_QUEATION11
@COUNT INT OUTPUT
AS
BEGIN

--DECLARE @COUNT INT
SELECT @COUNT= (SELECT COUNT(*) FROM TBLPROJECT)
PRINT @COUNT
SELECT *  FROM TBLPROJECT ORDER BY PNAME ASC

END

DECLARE @COUNT INT 
EXEC USP_QUEATION11 @COUNT = @COUNT OUTPUT
SELECT @COUNT

--5.Write a procedure to create a Temp table named Students with columns- 
--StudentId,StudentName and Marks where the  
--column StudentId is generated automatically  
--and insert data into the table and also retrieve the data. 
CREATE OR ALTER PROCEDURE USP_STUDENTS
AS
BEGIN
CREATE TABLE #STUDENTS(
STUDENTID INT IDENTITY(1,1),
STUDENTNAME VARCHAR(50),
MARKS INT
)
INSERT INTO #STUDENTS(STUDENTNAME,MARKS)
VALUES('SAGAR',90),
      ('NISHANTH',95),
	  ('RAJ',78)

	  SELECT STUDENTID,STUDENTNAME,MARKS
	  FROM #STUDENTS
END

EXEC USP_STUDENTS

--6.Write a procedure to perform the following DML operations on the column - 
--ProjectName in tblProject table by using a varibale.  
--Declare a local variable and initialize it to value 0, 
--1. When the value of the variable is equal to 2, then insert another record into the table 
--tblProject. 
--2. When the value of the variable is equal to 10, then change the ProjectName to 
--'Project_New' for input @ProjectId 

create or ALTER PROCEDURE USP_QUESTION12
@PEOJECTID INT,
@NEWPROJECTNAME VARCHAR(50)
AS
BEGIN
DECLARE @VARIABLE INT=0
IF @VARIABLE=2
BEGIN
INSERT INTO TBLPROJECT (PNAME)
VALUES ('SETUNION')
SET @VARIABLE =0
END
IF @VARIABLE=10
BEGIN
UPDATE TbLPROJECT
SET PNAME=@NEWPROJECTNAME
WHERE PROJECTID=@PEOJECTID

END
END

EXECUTE USP_QUESTION12 @PEOJECTID=1,@NEWPROJECTNAME='SETUNION'

SELECT*
FROM TBLPROJECT

--7.In the next part of the stored procedure, return all the fields of the table 
--tblProject(ProjectId,ProjectName,Code and Examyear) 
--based on the ProjectId and for the column ExamYear display it as given using CASE 
--statement. 
--1.If the ExamYear is greater than or equal to 2022 then display 'New' 
--2.If the ExamYear is lesser than or equal to 2022 then display 'Old' 
 CREATE PROCEDURE USP_QUESTION13
 @PROJECTID INT
 AS
 BEGIN
 SELECT PROJECTID,PNAME,PCODE,
 CASE
 WHEN EXAMYEAR>='2022' THEN 'NEW'
 WHEN EXAMYEAR<='2022' THEN 'OLD'
 END AS EXAMYEAR
 FROM TBLPROJECT
 WHERE PROJECTID=@PROJECTID
 END

 execute USP_QUESTION13 @PROJECTID=1
 execute USP_QUESTION13 @PROJECTID=2
  execute USP_QUESTION13 @PROJECTID=8

-------------------------------------ASSIGNMENT 10 --------------------------------------------

CREATE TABLE [tblUsers](
	[UserId]	VARCHAR(50)	Primary Key,
	[UserName]	VARCHAR(50)	NOT NULL,
	[Password]	VARCHAR(50)	NOT NULL,
	[Age]	INT	NOT NULL,
	[Gender]	CHAR(1)	NOT NULL,
	[EmailId]	VARCHAR(50)	UNIQUE,
	[PhoneNumber]	NUMERIC(10)	NOT NULL);

INSERT INTO [tblUsers]
VALUES
('mary_potter', 'Mary Potter', 'Mary@123', 25, 'F', 'mary_p@gmail.com', 9786543211),
('jack_sparrow', 'Jack Sparrow', 'Spar78!jack', 28, 'M', 'jack_spa@yahoo.com', 7865432102);


SELECT * FROM [tblUsers];

CREATE TABLE [tblTheatreDetails](
	[TheatreId]	INT	PRIMARY KEY, 
	[TheatreName] VARCHAR(50) NOT NULL,
	[Location] VARCHAR(50) NOT NULL);

INSERT INTO [tblTheatreDetails]
VALUES
	(1, 'PVR', 'Mysuru'),
	(2, 'Inox', 'Bengaluru');

SELECT * FROM [tblTheatreDetails];

CREATE TABLE [tblShowDetails](
	[ShowId] INT PRIMARY KEY IDENTITY(1001,1),
	[TheatreId] INT FOREIGN KEY REFERENCES [tblTheatreDetails]([TheatreId]),
	[ShowDate] DATE NOT NULL,
	[ShowTime] TIME NOT NULL,
	[MovieName] VARCHAR(50) NOT NULL,
	[TicketCost] DECIMAL(6,2) NOT NULL,
	[TicketsAvailable] INT NOT NULL);

INSERT INTO [tblShowDetails]
VALUES
	(1, '2023-11-28', '14:30:00', 'Avengers', 250.00, 100),
	(2, '2023-11-26', '17:30:00', 'Hit Man', 200.00, 150);

SELECT * FROM [tblShowDetails]

CREATE TABLE [tblBookingDetails](
c VARCHAR(5) PRIMARY KEY,
UserId VARCHAR(50) FOREIGN KEY REFERENCES tblUsers(UserId) NOT NULL,
ShowId INT FOREIGN KEY REFERENCES tblShowDetails(ShowId) NOT NULL,
NoOfTickets INT NOT NULL,
TotalAmt DECIMAL(6,2) NOT NULL);

INSERT INTO tblBookingDetails
VALUES
('B1001', 'mary_potter', 1001, 2, 500.00),
('B1002', 'jack_sparrow', 1002, 5, 1000.00);

SELECT * FROM tblBookingDetails

CREATE or alter PROCEDURE usp_BookTicket
( 
  @USERID VARCHAR(50),
  @SHOWID INT,
  @NOOFTICKET INT)
AS
BEGIN
	IF(@USERID NOT IN (SELECT USERID FROM tblUsers))
	BEGIN 
		PRINT 'USER ID IS INVALID'
		RETURN -1
	END 

	IF (@SHOWID NOT IN (SELECT SHOWID FROM tblBookingDetails))
	BEGIN
		PRINT 'SHOWID IS INVALID'
		RETURN -2
	END

	IF @NOOFTICKET<=0 
	BEGIN
		PRINT 'INVALID NUMBER OF TICKETS'
		RETURN -3
	END

	IF @NOOFTICKET>(SELECT TICKETSAVAILABLE FROM tblShowDetails WHERE SHOWID=@SHOWID)
	BEGIN
		PRINT 'Tickets Unavailable'
		RETURN -4
	END
	
	BEGIN TRY                                                                                                             --SELECT RIGHT(MAX([BookingId],4)+1)
	                                                                                	                                  --SELECt 'B'+1002                                                                                    --SELECT 'B'+CAST(1002 AS VARCHAR)
		BEGIN TRANSACTION

		--INSERT
			DECLARE @MaxId VARCHAR(5), @Price MONEY;
		
			SELECT 
				@MaxId= 'B'+CAST(RIGHT(MAX(c),4)+1 AS VARCHAR) 
			FROM tblBookingDetails

			SELECT @price=TicketCost
			FROM tblShowDetails
			WHERE ShowId = @ShowId

			INSERT INTO tblBookingDetails(c, UserId, ShowId, NoOfTickets, TotalAmt)
			VALUES
			(@MaxId, @USERID, @SHOWID, @NOOFTICKET, @Price*@NOOFTICKET);

			--UPDATE AVAILABLE TICKETS
			UPDATE tblShowDetails
			SET TicketsAvailable -= @NOOFTICKET
			WHERE ShowId = @ShowId;

		COMMIT
		RETURN 1
	END TRY

	BEGIN CATCH
		ROLLBACK
		PRINT 'OTHER EXCEPTION'
		RETURN -99
	END CATCH
END
 
SELECT * FROM tblUsers
SELECT * FROM tblTheatreDetails
SELECT * FROM tblShowDetails
SELECT * FROM tblBookingDetails

--	Function: ufn_GetMovieShowtimes 
--Create a function ufn_GetMovieShowtimes to get the show details based on the MovieName 
--and Location 
--Input Parameter: 
--MovieName 
--Location 
--Functionality: 
--Fetch the details of the shows available for a given MovieName in a location 
--Return Value: 
--A table containing following fields: 
--MovieName 
--ShowDate 
--ShowTime 
--TheatreName 
--TicketCost 

CREATE or alter FUNCTION ufn_GetMovieShowtimes(
@MovieName VARCHAR (20),
@Location VARCHAR(20))
RETURNS @MOVIETABLE TABLE 

(MovieName VARCHAR(20),
ShowDate DATE,
ShowTime TIME,
TheatreName VARCHAR(20),
TicketCost DECIMAL)
AS
BEGIN
INSERT INTO @MOVIETABLE
SELECT MovieName,ShowDate ,ShowTime,TheatreName ,TicketCost 
FROM tblTheatreDetails JOIN tblShowDetails
ON tblTheatreDetails.THEATREID=tblShowDetails.THEATREID
WHERE MOVIENAME=@MOVIENAME OR LOCATION=@LOCATION
RETURN
END

select * from dbo.ufn_GetMovieShowtimes( 'hit man','bengaluru')


--------------------------------------ASSIGNMENT11-----------------------------------------------------
select * from tblDepartment 
select * from tblSubject
tblDeptSub


CREATE TABLE tblDepartment 
						 (DId INT PRIMARY KEY,
						 DName VARCHAR(30)
						 );

INSERT INTO tblDepartment VALUES(1,'CS'),(2,'IS'),(3,'MECH');
SELECT * FROM tblDepartment;

CREATE TABLE tblSubject(SId INT PRIMARY KEY,
						SubName VARCHAR(30) NOT NULL
						);

INSERT INTO tblSubject VALUES(101,'C PROGRAMMING'),
							 (102,'PYTHON'),
							 (103,'H T M L'),
							 (104,'WEB DESIGN'),
							 (105,'SQL'),
							 (106,'DATA ANALYTICS'),
							 (107,'BIG DATA'),
							 (108,'.NET'),
							 (109,'THERMODYNAMICS'),
							 (110,'FLUID MECHINARY'),
							 (111,'MECHANICS OF MATERIALS'),
							 (112,'KINEMATICS');
							 
SELECT * FROM tblSubject;

CREATE TABLE tblDeptSub( DId INT FOREIGN KEY REFERENCES tbldepartment(Did),
                        SId int FOREIGN KEY REFERENCES tblsubject(sid)
						)

INSERT INTO tblDeptSub VALUES(1,101),(1,102),(1,103),(1,104),(1,105),
							 (2,106),(2,107),(2,105),(2,104),(2,108),
							 (3,109),(3,110),(3,111),(3,112),(3,101);

SELECT * FROM tblDeptSub;


SELECT * FROM tblMarks
SELECT * FROM tblStudent
SELECT * FROM tblDepartment;
SELECT * FROM tblSubject;
SELECT * FROM tblDeptSub;

CREATE TABLE tblStudent(StudentId INT PRIMARY KEY,
						StudentName VARCHAR(30),
						DepartmentId INT FOREIGN KEY REFERENCES tbldepartment(Did)
						);

INSERT INTO tblStudent VALUES(201,'anjali',1),(202,'pooja',2),(203,'bhoomika',3);

SELECT * FROM tblStudent;

CREATE TABLE tblMarks(StudentId INT FOREIGN KEY REFERENCES tblSTUDENT(StudentId),
				SubjectId INT  FOREIGN KEY REFERENCES tblsubject(sid),
				ExamDate DATE,
				SCore INT
				);

INSERT INTO tblMarks VALUES(201,101,'10-01-2023',80),
							(201,102,'10-02-2023',67),
							(201,103,'10-3-2023',87),-----passsing 47 above
							(201,104,'10-4-2023',91),
							(201,105,'10-5-2023',90),

							(202,106,'10-6-2023',76),
							(202,107,'10-7-2023',82),
							(202,105,'10-8-2023',86),
							(202,104,'10-9-2023',99),
							(202,108,'10-10-2023',34),

							
							(203,109,'10-11-2023',96),
							(203,110,'10-12-2023',82),
							(203,111,'10-13-2023',86),
							(203,112,'10-14-2023',99),
							(203,101,'10-15-2023',94);

--1.Each department has only five Subjects
--2.Some subjects can be a common subject between the departments
--3.Student can take test/assessment on the subjects as per his department
--4.Student can attempt only once in each subject
--5.The Pass marks is variable, a student must pass in all subjects  to Pass
--6.Grades are based on the percentage of scores, those above 79% would be graded as distinction
-- Those with 60 and above percentage would be graded as first class and those who score above
-- 50% are graded as second class, the remaining are classified as Just passed
-- Grades are awarded only to those who pass in all subjects
--1. Create a function to List the details as shown below for the students of a given department and
--given pass marks
--| StudentID | Name | Total Marks | Percent | age | No of Subjects Passed | No of Subjects attempted | Result | Grade|


CREATE OR ALTER FUNCTION ufn_report(@Dept INT ,@Marks INT)
RETURNS @reports table
(
	Id INT,
	Name varchar(50),
	TotalMarks INT,
	Percentage INT,
	NoOfPassed INT,
	NoOfSubjectsAttended INT,
	Result varchar(50),
	Grade Varchar(50))
AS
BEGIN
INSERT INTO @reports(Id,Name,TotalMarks,Percentage,NoOfSubjectsAttended,NoOfPassed,Result,Grade)
  
SELECT X.id,x.name,SUM(X.marks),SUM(X.MARKS)*100/(COUNT(X.MARKS)*100) AS PERCENTAGE,COUNT(X.MARKS) AS ATTEMPTED,
      COUNT(X.RESULT) AS PASSED,
	  CASE WHEN COUNT(X.MARKS)=COUNT(X.RESULT) THEN 'PASS'
	  ELSE 'FAIL'
	  END AS RESULTS,
	 
	 CASE 
	  WHEN (SUM(X.MARKS)*100/(COUNT(X.MARKS)*100)) >=80 AND COUNT(X.MARKS)=COUNT(X.RESULT) THEN 'DISTINCTION'
	  WHEN (SUM(X.MARKS)*100/(COUNT(X.MARKS)*100)) BETWEEN 70 AND 79 AND COUNT(X.MARKS)=COUNT(X.RESULT)THEN 'FIRST CLASS'
	  WHEN (SUM(X.MARKS)*100/(COUNT(X.MARKS)*100)) BETWEEN 60 AND 69 AND COUNT(X.MARKS)=COUNT(X.RESULT) THEN 'SECOND CLASS'
	  WHEN (SUM(X.MARKS)*100/(COUNT(X.MARKS)*100)) BETWEEN 50 AND 59 AND COUNT(X.MARKS)=COUNT(X.RESULT) THEN 'Third CLASS'
	-- WHEN (SUM(X.MARKS)*100/(COUNT(X.MARKS)*100)) <50 AND COUNT(X.MARKS)=COUNT(X.RESULT) THEN 'fourth class'
	  else '---'
	  END AS GRADE

from 

  (SELECT M.StudentId AS ID ,S.StudentName AS NAME ,M.subjectid AS SubId,S.DepartmentId as Dept,M.SCore as marks,CASE
																	WHEN 
																	m.SCORE>=@marks THEN 1
																	ELSE NULL
																	END as RESULT
  FROM tblStudent S
  INNER JOIN tblMarks M
  ON S.StudentId=M.StudentId) X
WHERE x.Dept=@Dept
GROUP BY x.id,x.Name
RETURN
END

select * from dbo.ufn_report(1,35)--d
select * from dbo.ufn_report(3,50)--s
select * from dbo.ufn_report(2,34)--f

select * from dbo.ufn_report(3,35)--s

seleCT * from dbo.ufn_report(3,52)--fail

select * from dbo.ufn_report(3,72)


SELECT * FROM tblMarks
SELECT * FROM tblStudent
SELECT * FROM tblDepartment;
SELECT * FROM tblSubject;
SELECT * FROM tblDeptSub;
-----------------------------------------------------------------------------------------------

update tblmarks 
SET score=35
where studentid=201 and subjectid=101



CREATE OR ALTER FUNCTION ufn_report(@Dept INT ,@Marks INT)
RETURNS @reports table
(
	Id INT,
	Name varchar(50),
	TotalMarks INT,
	Percentage varchar(50),
	NoOfPassed INT,
	NoOfSubjectsAttended INT,
	Result varchar(50),
	Grade Varchar(50))
AS
BEGIN
INSERT INTO @reports(Id,Name,TotalMarks,Percentage,NoOfSubjectsAttended,NoOfPassed,Result,Grade)
  
SELECT X.id,x.name,SUM(X.marks),concat(cast(SUM(X.MARKS)*100/(COUNT(X.MARKS)*100) as varchar(50)),'%') AS PERCENTAGE,COUNT(X.MARKS) AS ATTEMPTED,
      COUNT(X.RESULT) AS PASSED,
	  CASE WHEN COUNT(X.MARKS)=COUNT(X.RESULT) THEN 'PASS'
	  ELSE 'fail'
	  END AS RESULTS,
	 
	 CASE 
	  WHEN (SUM(X.MARKS)*100/(COUNT(X.MARKS)*100)) >=80 AND COUNT(X.MARKS)=COUNT(X.RESULT) THEN 'DISTINCTION'
	  WHEN (SUM(X.MARKS)*100/(COUNT(X.MARKS)*100)) BETWEEN 70 AND 79 AND COUNT(X.MARKS)=COUNT(X.RESULT)THEN 'FIRST CLASS'
	  WHEN (SUM(X.MARKS)*100/(COUNT(X.MARKS)*100)) BETWEEN 60 AND 69 AND COUNT(X.MARKS)=COUNT(X.RESULT) THEN 'SECOND CLASSN'
	  WHEN (SUM(X.MARKS)*100/(COUNT(X.MARKS)*100)) BETWEEN 50 AND 59 AND COUNT(X.MARKS)=COUNT(X.RESULT) THEN 'Third CLASSN'
	  WHEN (SUM(X.MARKS)*100/(COUNT(X.MARKS)*100)) <50 AND COUNT(X.MARKS)=COUNT(X.RESULT) THEN 'fourth class'
	  else 'fail'
	  END AS GRADE

from 

  (SELECT M.StudentId AS ID ,S.StudentName AS NAME ,M.subjectid AS SubId,S.DepartmentId as Dept,M.SCore as marks,CASE
																	WHEN 
																	m.SCORE>=@marks THEN 1
																	ELSE NULL
																	END as RESULT
  FROM tblStudent S
  INNER JOIN tblMarks M
  ON S.StudentId=M.StudentId) X
WHERE x.Dept=@Dept
GROUP BY x.id,x.Name
RETURN
END

select * from dbo.ufn_report(1,35)--d
select * from dbo.ufn_report(3,55)--d

select * from dbo.ufn_report(2,34)--f
select * from dbo.ufn_report(3,35)--s

----------------------------------------------POSTGRESQL to SSMS-----------------------------------------------------------

create table tblusers1(
user_id INT primary key,
user_name varchar(50) not null,
email varchar(50) not null)

insert into tblusers1(user_id,user_name,email)
values
(1001,'Akash','akash@gmail.com'), 
(1002,'Arvind','arvind123@gmail.com'), 
(1003,'Sakshi','sakshimys12@gmail.com'),
(1004,'Kumar','kumar987@gmail.com')
 
create table tblcategory1(
category_id INT primary key,
category_name varchar(20) not null,
description varchar(50) not null)

insert into tblcategory1(category_id,category_name,description)
values
(201,'Electronics','One stop for electronic items'), 
(202,'Apparel','Apparel is the next destination for fashion'), 
(203,'Grocery','All needs in one place') 

create table tblproducts1(
product_id INT primary key,
product_name varchar(30) not null,
quantity int not null,
product_price int not null,
category_id int references tblcategory1(category_id));

insert into tblproducts1(product_id,product_name,quantity,product_price,category_id)
values
(1,'Mobile Phone',1000,15000,201),
(2,'Television',500,40000,201) ,
(3,'Denims',2000,700,202) ,
(4,'Vegetables',4000,40,203 ),
(5,'Ethnic Wear',300,1500,202) ,
(6,'Wireless Earphone',5000,2500,201 ),
(7,'Lounge Wear',200,1600,202 ),
(8,'Refrigerator',50,30000,201 ),
(9,'Pulses',60,150,202) ,
(10,'Fruits',100,250,203) ;

create table tblsales1(
sales_id  INT primary key,
sales_user_id int FOREIGN KEY REFERENCES tblusers1(user_id),
product_id int FOREIGN KEY REFERENCES tblproducts1(product_id));

insert into tblsales1(sales_id,sales_user_id,product_id)
values
(500,1001,1 ),
(501,1002,1 ),
(502,1003,2 ),
(504,1004,3 ),
(505,1004,1 ),
(506,1004,1 ),
(507,1002,2 ),
(508,1003,1 ),
(509,1001,7 ),
(510,1001,8 );
 
  select * from tblusers1
 select * from tblcategory1
 select * from tblproducts1
select * from tblsales1

CREATE OR ALTER FUNCTION fnSales (@SaleID INT)
RETURNS @Result TABLE (ProductName VARCHAR(100), CategoryName VARCHAR(100), UserName VARCHAR(100), ProductID INT, ProductPrice INT,REMARKS VARCHAR(100))
AS
BEGIN
INSERT INTO @Result
SELECT P.Product_Name, Category_Name , User_Name , S.Product_ID , Product_Price,
CASE WHEN product_price >2000 THEN 'PROFIT '
     WHEN product_price between 1001 and 2000 THEN 'average '
     WHEN product_price between 500 AND 1000 THEN 'loss '
	 WHEN product_price<500 THEN 'NO PROFIT NO LOSS ' enD AS REMARKS
FROM tblcategory1 C
INNER JOIN tblProducts1 P ON C.Category_ID= P.Category_ID
INNER JOIN tblSales1 S ON S.Product_ID= P.Product_ID
INNER JOIN tblUsers1 U ON U.User_ID= S.sales_user_id
WHERE S.sales_id= @SaleID
RETURN
END
 insert into tblsales1(sales_id,sales_user_id,product_id)
 values(511,1002,4)
 insert into tblsales1(sales_id,sales_user_id,product_id)
 values(512,1003,5)


SELECT * FROM fnSales(512)
SELECT * FROM fnSales(5)


----------------------sp
2.Write a procedure to update the name of the category from 'Electronics' to 'Modern Gadgets' and 
also  
fetch the category and product names when the userid is passed as the input parameter.

CREATE OR ALTER PROCEDURE uspUpdateCategory
@UserID INT
AS
BEGIN

	UPDATE tblCategory1
	SET category_name= 'Modern Gadgets'
	WHERE category_name= 'Electronics'

	if @UserID in(select USER_ID from tblusers1)
	 begin
		SELECT C.category_name, P.product_name,sum(p.product_price)
		FROM tblSales1 S
		INNER JOIN tblProducts1 P ON S.product_id = P.product_id
		INNER JOIN tblCategory1 C ON P.category_id = C.category_id
		WHERE S.sales_user_id = @UserID
		group by C.category_name, P.product_name
	end
	else
	begin
		print'userid does not exist'
	end
  
END;

EXEC uspUpdateCategory 1004


select * from tblusers1
 select * from tblcategory1
 select * from tblproducts1
select * from tblsales1


