
----stored proceudre

1.Consider table tblEmployeeDtls and write a stored procedure to generate 
bonus to employees for the given date  as below: 
A)One month salary  if Experience>10 years  
B)50% of salary  if experience between 5 and 10 years  
C)Rs. 5000  if experience is less than 5 years 
Also, return the total bonus dispatched for the year as output parameter. 

CREATE OR REPLACE PROCEDURE usp_result
( in givendate DATE DEFAULT NOW()::DATE,
inout bonus bigint default null
)
as
$$
begin
with bonustbl as(
SELECT 
hire_date,
salary,
extract(year from age(givendate,hire_date)) as experience,
   (case
     when extract(YEAR FROM age(givendate,hire_date))>10 
	 then salary
	 when extract(YEAR FROM age(givendate,hire_date)) between 5 and 10
	 then salary * (50.0/100)
else 
	5000
   end) as bonusamt
   from employees)
   select sum(bonusamt) into bonus
   from bonustbl;
end;
$$
language plpgsql;

call usp_result('2023-07-10')



CREATE FUNCTION fn_ans1(val int)
RETURNS int
AS
$$
BEGIN
  return val+1;
END
$$
LANGUAGE plpgsql;

select fn_ans1(10)














 select * from employees
 