create table tblusers(
user_id serial primary key,
user_name varchar(50) not null,
email varchar(50) not null)

insert into tblusers(user_id,user_name,email)
values
(1001,'Akash','akash@gmail.com'), 
(1002,'Arvind','arvind123@gmail.com'), 
(1003,'Sakshi','sakshimys12@gmail.com'),
(1004,'Kumar','kumar987@gmail.com')
 
create table tblcategory(
category_id serial primary key,
category_name varchar(20) not null,
description varchar(50) not null)

insert into tblcategory(category_id,category_name,description)
values
(201,'Electronics','One stop for electronic items'), 
(202,'Apparel','Apparel is the next destination for fashion'), 
(203,'Grocery','All needs in one place') 

create table tblproducts(
product_id serial primary key,
product_name varchar(30) not null,
quantity int not null,
product_price int not null,
category_id int references tblcategory(category_id));

insert into tblproducts(product_id,product_name,quantity,product_price,category_id)
values
(1,'Mobile Phone',1000,15000,201),
(2,'Television',500,40000,201) ,
(3,'Denims',2000,700,202) ,
(4,'Vegetables',4000,40,203 ),
(5,'Ethnic Wear',300,1500,202) ,
(6,'Wireless Earphone',5000,2500,201 ),
(7,'Lounge Wear',200,1600,202 ),
(8,'Refrigerator',50,30000,201 ),
(9,'Pulses',60,150,202) ,
(10,'Fruits',100,250,203) ;

create table tblsales(
sales_id  serial primary key,
sales_user_id int references tblusers(user_id),
product_id int references tblproducts(product_id));

insert into tblsales(sales_id,sales_user_id,product_id)
values
(500,1001,1 ),
(501,1002,1 ),
(502,1003,2 ),
(504,1004,3 ),
(505,1004,1 ),
(506,1004,1 ),
(507,1002,2 ),
(508,1003,1 ),
(509,1001,7 ),
(510,1001,8 );
 
  select * from tblusers
 select * from tblcategory
 select * from tblproducts
select * from tblsales

1.Write a function to fetch the names of the product,category and users along with the cost for each 
product sold 
depending on the sales_id. 
Also if the cost for each product is more than 2000, then display a message stating 
that 'The product has gained profit'.  
If the product cost is between 500 and 1000, then raise a message stating that 
'The product has occured loss'.  
If the product cost is less than 500, then raise an exception stating 'No profit no loss'. 
 
CREATE OR REPLACE FUNCTION nameandcost(IN saleid int)

  Returns table (product_name1 varchar(50),
				 category_name1 varchar(50),
				 user_name1 varchar(50),
				 product_id1 int,
				 product_price1 int)
    Language plpgsql
 as
  $$
     DECLARE cost1 int;
  Begin
    return query
     SELECT p.product_name,category_name,User_name,s.product_id,product_price as price
     FROM tblCategory c 
     INNER JOIN tblProducts p on c.category_id=p.category_id
     INNER JOIN tblSales s on s.product_id=p.product_id
     INNER JOIN tblUsers u on u.user_id=s.sales_user_id
     WHERE s.sales_id=saleid ;
  
    SELECT P.product_price INTO cost1  
	FROM tblProducts P 
	INNER JOIN tblsales S USING(Product_id)
    WHERE s.sales_id=saleid;

IF cost1>2000 
THEN
RAISE NOTICE 'The product has gained profit';
END IF;

IF cost1>500 AND cost1<1000 
THEN
RAISE NOTICE 'The product has occured loss';
END IF;

IF cost1<500 
THEN
RAISE notice 'No profit no loss';
END IF;
END;
$$

select * from nameandcost(510)
 
 
2.Write a procedure to update the name of the category from 'Electronics' to 'Modern Gadgets' and 
also  
fetch the category and product names when the userid is passed as the input parameter. 
 
select * from tblusers
 select * from tblcategory
 select * from tblproducts
select * from tblsales

CREATE OR REPLACE PROCEDURE finalresult( IN  userID INT,
  INOUT Cname VARCHAR(30) DEFAULT NULL,
  INOUT Pname VARCHAR(30) DEFAULT NULL)
LANGUAGE PLPGSQL
AS $$
BEGIN
   UPDATE  tblcategory
   SET Category_Name='Modern Gadgets'
   WHERE Category_Name='Electronics';

SELECT
P.Product_Name INTO Pname
FROM
tblSales s INNER JOIN tblProducts p USING(Product_Id)
INNER JOIN tblCategory c USING(Category_Id)
WHERE s.Sales_user_id=userID;

SELECT
C.Category_Name INTO Cname
FROM
tblSales s INNER JOIN tblProducts p USING(Product_Id)
INNER JOIN tblCategory c USING(Category_Id)
WHERE s.Sales_user_id=userID;

END;
$$

CALL finalresult(1001);


 
