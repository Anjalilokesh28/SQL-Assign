SELECT * FROM tblactors
SELECT * FROM tbldirectors
SELECT * FROM tblmovies

update tblmovies
set movie_lang ='kannada'
where movie_id in (5,6,7);
order by movie_id asc
 
--1.Display Movie name, movie language and release date from movies table. 
SELECT movie_name,movie_lang,release_date
from tblmovies;

--2.Display only 'Kannada' movies from movies table. 
SELECT movie_name
from tblmovies
where movie_lang='kannada'

order by movie_id asc

--3.Display movies released before 1st Jan 2011. 
select *
from tblmovies
where release_date<'2011-01-01';

--4.Display Hindi movies with movie duration more than 150 minutes.
select movie_name
from tblmovies
where movie_lang='TAMIL' AND movie_length>150;

--5.Display movies of director id 3 or Kannada language. 
select *
from tblmovies
where director_id =3 or movie_lang='kannada'
order by director_id 

--6.Display movies released in the year 2023. 
select movie_name
from tblmovies
where extract(year from release_date)='2023';

--7.Display movies that can be watched below 15 years. 
select *
from tblmovies
where extract (year from release_date)<15;

--8.Display movies that are released after the year 2015 and directed by directorid 3.
select *
from tblmovies
where extract (year from release_date)>2015 AND director_id=3;

--9.Display all other language movies except Hindi language. 
select *
from tblmovies
where movie_lang !='hindi';

--10.Display movies whose language name ends with 'u'. 
select movie_name
from tblmovies
where movie_lang LIKE '%u';

--11.Display movies whose language starts with 'm'. 
select movie_name
from tblmovies
where movie_lang LIKE 'm%';

--12.Display movies with language name that has only 5 characters. 
select movie_lang
from tblmovies
where length(movie_name)=5 ;

--13.Display the actors who were born before the year 1980. 
select first_name,last_name
from tblactors
where date_of_birth<'1982';

--14.Display the youngest actor from the actors table. 
select first_name,last_name
from tblactors
order by date_of_birth DESC
Limit 1;

--15.Display the oldest actor from the actors table. 
select first_name,last_name
from tblactors
order by date_of_birth ASC
Limit 1;

--16.Display all the female actresses whose ages are between 30 and 35. 

select first_name as FIRSTNAME,
EXTRACT(YEAR FROM AGE(NOW(),date_of_birth)) AS AGE
from tblactors
	
--17.Display the actors whose movie ids are in 1 to 5. 
select first_name
from tblactors
where movie_id >=1 AND movie_id<=5;

--18.Display the longest duration movie from movies table. 
select *
from tblmovies
order by movie_length DESC
Limit 1;

--19.Display the shortest duration movie from movies table. 
select *
from tblmovies
order by movie_length ASC
Limit 1;

--20.Display the actors whose name starts with vowels. 

select first_name 
FROM tblactors
where Substring(first_name, 1,1) in ('V','E','I','O','U');


--21.Display all the records from tblactors by sorting the data based on the fist_name in the 
--ascending order and date of birth in the descending order. 
select *
from tblactors
order by first_name ASC,
date_of_birth Desc;

--22.Write a query to  return the data related to movies by arranging the data in ascending order 
--based on the movie_id and also fetch the data from the fifth value to the twentieth value. 

select movie_name,release_date
from tblmovies
order by movie_id ASC
offset 4 rows fetch first 10 rows 
	
update tblmovies
set movie_lang='hindi'
where movie_id = 7;			
---------------------------------------asgn2-------------------------------------------------------------		
SELECT * FROM tblactors
SELECT * FROM tbldirectors
SELECT * FROM tblmovies		
			
--1.List the different languages of movies. 
select distinct movie_lang
from tblmovies;
			
--2.Display the unique first names of all directors in ascending order by 
--their first name and then for each group of duplicates, keep the first row in the returned result set. 			
			
select distinct on(first_name)*
from tbldirectors
order by first_name ;
			
--3.write a query to retrieve 4 records starting from the fourth one, to 
--display the actor ID, name (first_name, last_name) and date of birth, and 
--arrange the result as Bottom N rows from the actors table according to their date of birth.			
select actor_id,CONCAT(first_name,'',last_name)AS "NAME",date_of_birth
from tblactors
order by date_of_birth,actor_id
limit 3 offset 4 rows			
			
--4.Write a query to get the first names of the directors who holds the letter 'S' or 'J' in the first name.     			
select first_name,
from tbldirectors 
where first_name LIKE '%S%' or first_name LIKE '%J%';
			
select *
from tblactors
where upper(first_name) like '%a%' OR
 lower(first_name) like '%e%' OR
 lower(first_name) like '%i%' OR
 lower(first_name) like '%o%' OR
 lower(first_name) like '%u%';
			
--5.Write a query to find the movie name and language of the movie of all the movies where the director name is Joshna. 

SELECT movie_name, movie_lang
FROM tblmovies m 
join tbldirectors d
on m.director_id =d.director_id
WHERE d.first_name = 'Joshna';

--6.Write a query to find the number of directors available in the movies table.
select count(director_id) 
from tblmovies;			
	
--7.Write a query to find the total length of the movies available in the movies table. 
SELECT SUM(movie_length) as totallength
FROM tblmovies;
			
--8.Write a query to get the average of movie length for all the directors who are working for more than 1 movie. 
select director_id,avg(movie_length)
from tblmovies
group by director_id
having count(*)>1;
			
select d.director_id,d.first_name ,avg(movie_length)
from tblmovies m
join tbldirectors d
on m.director_id=d.director_id
group by d.director_id
having count(*)>1;			
			
SELECT * FROM tblactors
SELECT * FROM tbldirectors
SELECT * FROM tblmovies	
			
--9.Write a query to find the age of the actor vijay for the year 2001-04-10. 
    SELECT AGE('2023-11-28','2001-04-10');
			
--10.Write a query to fetch the week of this release date 2020-10-10 13:00:10. 
	SELECT
	release_date,		
	TO_CHAR( release_date,'DW' ) AS release_week
			from tblmovies
			where release_date='2023-10-08 13:00:10' ;
			
--11.Write a query to fetch the day of the week and year for this release date 2020-10-10      			
 SELECT
	release_date,
	TO_CHAR(release_date ,'DD') AS release_day,
			TO_CHAR(release_date ,'YYYY') AS release_year
			from tblmovies
			WHERE release_date='2023-10-08';
		
SELECT
	release_date,
	TO_CHAR(release_date ,'DAY') AS release_day,
	TO_CHAR(release_date ,'YYYY') AS release_year,
	TO_CHAR(release_date,'DW') AS relase_week		
	from tblmovies
	WHERE release_date='2023-10-08';
						
			 
--12.Write a query to convert the given string '20201114' into date and time.			
select TO_DATE('20201114','YYYYMMDD'); 	
			
select TO_TIMESTAMP('20201114','YYYYMMDD');	
			
--13.--Display Today's date. 
 select CURRENTDATE();		
SELECT CURRENT_DATE;
			
--14.--Display Today's date with time.
	select now();		
			
	select now()::timestamp	
			
	SELECT CURRENT_TIMESTAMP AS today_date_with_time;
		
--15.Write a query to add 10 Days 1 Hour 15 Minutes to the current date. 	

SELECT CURRENT_TIMESTAMP + INTERVAL '10 days 1 hour 15 minutes' AS modified_date;
			
--16.Write a query to find the details of those actors who contain eight or more characters in their first name. 	
	select actor_id,first_name
	from tblactors
	where LENGTH(first_name)>=8
			
	select *
	from tblactors
	where LENGTH(last_name)>=8		
			
--17.Write a query to join the text 'movie' with the movie_name column. 
SELECT CONCAT('movie', movie_name) AS full_movie_name
FROM tblmovies;
			SELECT CONCAT('Film', movie_name) AS full_movie_name
FROM tblmovies;

--18.Write a query to get the actor id, first name and birthday month of an 
actor. 			
SELECT actor_id, first_name, EXTRACT(MONTH FROM date_of_birth) AS birth_month
FROM tblactors;
			SELECT actor_id, first_name, EXTRACT(DAY FROM date_of_birth) AS Day
FROM tblactors;
			SELECT actor_id, first_name, EXTRACT(DAY FROM date_of_birth) AS birth_month
FROM tblactors
			where actor_id =20;
			
			
--19.Write a query to get the actor id, last name to discard the last three 
characters. 		
	select actor_id,LEFT(last_name,LENGTH (last_name)-3) as discarded_last_name
	from tblactors;		
			
	select actor_id,RIGHT(last_name,LENGTH (last_name)-3) as discarded_last_name
	from tblactors;		
	
	select actor_id,LEFT(first_name,LENGTH (first_name)-3) as discarded_first_name
	from tblactors;			
			
--20.Write a query that displays the first name and the character length of 
--the first name for all directors whose name starts with the letters 'A', 'J' or 'V'. 
--Give each column an appropriate label. Sort the results by the directors' first 
--names. 
select first_name,LENGTH(first_name)
from tbldirectors
where upper(first_name) like 'A%' OR
 upper(first_name) like 'J%' OR
 upper(first_name) like 'V%' 
order by first_name;
			
select director_id,first_name as director_first_name,LENGTH(first_name) as Namelength
from tbldirectors
where upper(first_name) like 'A%' OR
upper(first_name) like 'J%' OR
upper(first_name) like 'V%' 
order by first_name ;
			
			
--21.Write a query to display the first word in the movie name if the movie name contains more than one words. 
	select 	movie_name
	from tblmovies
	where LENGTH(movie_name)>1;		
			
SELECT 	movie_name,split_part(movie_name,'',1)	
from tblmovies
where movie_name LIKE '% %';			
			
--22.Write a query to display the actors name with movie name.       					
select a.actor_id,a.first_name,a.last_name,m.movie_id,m.movie_name
from tblactors a
join tblmovies m
on a.movie_id = m.movie_id
order by a.actor_id;			
			
--23.Write a query to make a join with three tables movies, actors, and 
--directors to display the movie name, director name, and actors date of birth.
		select m.movie_name,d.director_na
	
--24.Write a query to make a join with two tables directors and movies to 
--display the status of directors who is currently working for the movies above 1. 			
select d.director_id,d.first_name,m.movie_id
from tbldirectors d
join tblmovies m
on d.director_id = m.director_id
group by d.director_id,m.movie_id
having count(m.movie_id)>1;			
			
--25.Write a query to make a join with two tables movies and actors to get 
--the movie name and number of actors working in each movie. 
	select m.movie_name, count(actor_id) as numofactors
	from tblmovies m
	join tblactors a
	on m.movie_id = a.movie_id
	group by m.movie_name				
			
			
--26.Write a query to display actor id, actors name (first_name, last_name)  
--and movie name to match ALL records from the movies table with each record from the actors table.      
 		
SELECT a.actor_id, a.first_name, a.last_name, m.movie_name
FROM actors a
CROSS JOIN movies m;
	

			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			