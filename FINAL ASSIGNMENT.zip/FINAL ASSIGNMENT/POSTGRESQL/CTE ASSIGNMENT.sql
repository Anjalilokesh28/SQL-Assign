    -----CTE ASGN4-----

-- 1.Write a query to fetch the student_name,stipend and department_name from the students and departments 
-- table where the student_id is between 1 to 5 AND stipend is in the range of 2000 to 4000.
  select * from students
  select * from departments1
  
     WITH student_department(sname,stipend,dname)
	 AS (
		 select student_name,stipend,department_name
		 from students join departments1
		 on student_department = department_id
	 where student_id BETWEEN 1 AND 5 
	 AND stipend BETWEEN 2000 AND 4000)
		 
		 select sname,stipend,dname
		 from student_department;
   
--2.Write a query to fetch the sum value of the stipend from the students table based on the 
--department_id where the departments 'Animation' and 'Marketing' should not be 
--included and the sum value should be less than 4000.
      WITH fetch_value(sname,total,dept)
	  AS(
	      SELECT student_name,SUM(stipend),department_id
		  from students   join departments1 
		 on student_department = department_id
		  where department_name NOT IN('Animation','Marketing') 
		  GROUP BY student_name, department_id
		  HAVING sum(stipend) <4000
	  )
          select sname,total,dept
		 from fetch_value;
     
--3.Using the concept of multiple cte, fetch the maximum value, minimm value, average and sum of the 
--stipend based on the department and return all the values.
 
with display_stipend1
as(
select  max(stipend) as maxi,student_department
	from students
	group by student_department
),
   display_stipend2
as(
select  min(stipend) as mini,student_department
	from students
	group by student_department
),
display_stipend3
as(
select  avg(stipend) as avge ,student_department
	from students
	group by student_department
),
 display_stipend4
as(
select  sum(stipend) as sumof ,student_department
	from students
	group by student_department
)
 select D1.maxi,D2.mini,D3.avge,D4.sumof ,D1.student_department
 from  display_stipend1 D1 inner JOIN display_stipend2 D2 
 ON  D1. student_department= D2.student_department
 inner JOIN display_stipend3 D3 
 ON  D2. student_department= D3.student_department
 inner JOIN display_stipend4 D4
 ON  D3. student_department= D4.student_department
 
--------------------------------------------------------------------------------------------------------------------- 
create table tblDepartment(
dept_id int primary key,
dept_name varchar(10));

insert into tblDepartment(dept_id,dept_name )
values(1,'HR'),
      (2,'IT'),
      (3,'FINANCE'),
      (4,'ACCOUNTS')
	  
SELECT * FROM  tblDepartment
	 
create table tblemployee(
empid int,
fname varchar(10),
lname varchar(10),
gender varchar(5),
salary money,
dept_id int references tbldepartment(dept_id));

insert into tblemployee(empid,fname,lname,gender,salary,dept_id )
values(1,'PRIYA','GOWDA','F',2000,1),
       (2,'TINA','ROY','F',45000,1),
       (3,'STEVE','SMITH','M',93000,2),
       (4,'GAURAV','RAJ','M',56000,3),
	   (5,'SMRITI','VIKAS','F',10000,3),
	   (6,'ANNIE','MARY','F',75000,2),
	   (7,'MANOJ','GOWDA','M',27000,3)
	   
SELECT * FROM  tblemployee
	 	   
------CTE WITH query to list down all employees with Gender as Female
 
WITH CTE_EMP (emp_id,first_name,last_name,gender) as
(SELECT empid,fname,lname,
(CASE 
 WHEN gender='M' THEN 'Male'
 wHEN gender='F' THEN 'Female'
END) gender
 from tblemployee)
 select * from CTE_EMP where gender='Female';
 






