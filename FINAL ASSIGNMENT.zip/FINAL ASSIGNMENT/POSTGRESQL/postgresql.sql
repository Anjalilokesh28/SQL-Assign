
CREATE TABLE departments
(department_id NUMERIC PRIMARY KEY,
department_name VARCHAR(20));

create TABLE employees
( employee_id NUMERIC PRIMARY KEY, 
department_id NUMERIC REFERENCES departments,
first_name VARCHAR(200) NOT NULL, 
last_name VARCHAR(200) NOT NULL,
email_id VARCHAR(200) UNIQUE, 
phonenumber VARCHAR(200),
hire_date DATE DEFAULT CURRENT_DATE,
job_id VARCHAR(200),
salary NUMERIC CHECK (salary > 0 ), 
manager_id NUMERIC REFERENCES employees 
ON DELETE SET NULL ON UPDATE SET NULL, 
commission_pct numeric(2,2) );



create TABLE job_history
(employee_id NUMERIC,
start_date DATE,
end_date DATE,
job_id VARCHAR(20),
department_id NUMERIC REFERENCES departments 
ON DELETE SET NULL ON UPDATE SET NULL,
CONSTRAINT emp_date PRIMARY KEY (employee_id,start_date), 
CONSTRAINT empid_fk foreign key (employee_id) references employees 
ON DELETE SET NULL ON UPDATE SET NULL,
CONSTRAINT job_hist_date CHECK (start_date < end_date) );


INSERT INTO departments (department_id, department_name)
VALUES (10, 'HR'),
       (20, 'Finance'),
       (30, 'IT'),
       (40, 'Marketing'),
       (50, 'Operations');
	   
	   
	  INSERT INTO employees (employee_id,department_id, first_name, last_name, email_id, phonenumber, job_id, salary, manager_id, hire_date)
VALUES (1,10, 'John', 'Doe', 'john.doe@example.com', '123456789', 'Manager', 60000, NULL, '2023-01-01'),
       (2,20,'Jane', 'Smith', 'jane.smith@example.com', '987654321', 'Analyst', 50000, 1, '2023-02-15'),
       (3,30, 'Bob', 'Johnson', 'bob.johnson@example.com', '555123456', 'Developer', 70000, 1, '2023-03-20'),
       (4,40, 'Alice', 'Williams', 'alice.williams@example.com', '444555666', 'Coordinator', 45000, 2, '2023-04-10'),
       (5,50,'Charlie', 'Brown', 'charlie.brown@example.com', '333222111', 'Administrator', 55000, 2, '2023-05-05');
 
	   
INSERT INTO job_history (employee_id, start_date, end_date, job_id, department_id)
VALUES (2, '2023-02-15', '2023-06-30', 'Analyst', 20),
       (3, '2023-03-20', NULL, 'Developer', 20),
       (4, '2023-04-10', NULL, 'Coordinator', 30),
       (5, '2023-05-05', NULL, 'Administrator', 30),
       (1, '2023-01-01', '2023-12-31', 'Manager', 10);
	    
select * from departments
select * from employees
select * from job_history

11.
SELECT last_name, ROUND(months between(sysdate,hiredate)as month_worked)
from employees;

12. SELECT department_id, job_id,(SUM(salary+(salary*commission_pct))) AS total_spending
FROM employees
GROUP BY department_id, job_id;

13.calculate the following details of the employees using aggregate function in a 
department. 
∙Employee with highest salary 
∙Employee with lowest salary 
∙Total salary of all the employees in the department  
∙Average salary of the department 

select first_name,salary 
from employees
where salary =(select max(salary) from employees);

select first_name,salary 
from employees
where salary =(select min(salary) from employees);

select department_id,sum(salary) as totalsalary
from employees
group by department_id;

select department_id,avg(salary) avgsal
from employees e
group by department_id

14.Modify the result obtained in the previous exercise to display the minimum, 
maximum, total and average salary for each job type. 
15.fetch the details of the departments having less than 3 employees and are working in 
the department whose department_id is greater than 10.  
SELECT department_id,count(*) as num_employees
FROM employees
GROUP BY department_id 
HAVING num_employees<3 and department_id>10;
  
17.details OF the employees who have never changed their job ROLE IN the company. 
SELECT *
FROM employees
WHERE employee_id NOT IN (SELECT DISTINCT employee_id FROM job_history);

18. SELECT e.first_name, e.last_name, d.department_name
FROM employees e
JOIN departments d ON e.department_id = d.department_id;

select * from departments
select * from employees
select * from job_history

19. SELECT d.*, e.first_name, e.last_name
FROM departments d
LEFT JOIN employees e ON d.department_id = e.department_id;

20.details of the employee along with their managers. 
select e.employee_id,e.first_name,e.last_name,e.email_id,m.manager_id
from employees e
join employees m 
on e.manager_id = m.employee_id;

select e.employee_id,e.first_name,e.last_name,m.first_name
from employees e
join employees m 
on e.manager_id = m.employee_id;

21.employee details who are reporting to the same manager as Maria reports to. 
22.fetch the details of the employees working in the Executive department. 
select *
from employees e
join departments d 
on e.department_id = d.department_id
where d.department_name ='Executive'

UPDATE Departments
set department_name='Executive'
where department_id = 10;

select *
from employees e
join departments d 
on e.department_id = d.department_id
where d.department_name ='hr'

23.fetch the details of employee whose salary is greater than the average salary of all 
the employees. 
select *
from employees
where salary>(select avg(salary) from employees);

26.Write a query to display the last name and salary of those who reports to King. williams
select last_name,salary
from employees
where manager_id =(select employee_id from employees where last_name='john' );

27.Write a query to display the below requirement.   
Fetch employee id and first name of who work in a department with the employee's having 
‘u’ in the  last_name. 




